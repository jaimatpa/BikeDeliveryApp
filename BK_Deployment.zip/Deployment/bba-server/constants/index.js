/**************************
  Number Constant Variables
***************************/
const NUMBER_0 = 0
const NUMBER_1 = 1
const NUMBER_16 = 16
const NUMBER_32 = 32
const NUMBER_64 = 64
const NUMBER_465 = 465

module.exports = {
    NUMBER_0,
    NUMBER_1,
    NUMBER_16,
    NUMBER_32,
    NUMBER_64,
    NUMBER_465
}