import Vue from 'vue'
import DatetimePicker from 'vuetify-datetime-picker'
// (Optional) import 'vuetify-datetime-picker/src/stylus/main.styl'

// Vue.component("DatetimePicker", DatetimePicker);
Vue.use(DatetimePicker)