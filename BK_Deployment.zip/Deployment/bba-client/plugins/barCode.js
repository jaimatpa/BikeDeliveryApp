import Vue from "vue";
import { StreamBarcodeReader } from "vue-barcode-reader";

Vue.component("StreamBarcodeReader", StreamBarcodeReader);
Vue.use(StreamBarcodeReader);
